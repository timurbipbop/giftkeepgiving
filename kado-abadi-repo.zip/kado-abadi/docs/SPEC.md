# Kado Abadi — Product Spec

2026-09-22 · Alfa. Living version of this spec is the Claude Doc; this file is the snapshot that ships with the repo.

## What this is

Kado Abadi is a way to send love as a perpetual fund. You pick an occasion, a person, a cause and an amount; the platform mints a stamped poster with a QR code, delivers it via WhatsApp from Kitabisa, and the gift keeps producing impact in that person's name for as long as the pool exists.

There is no one-time donation and no spend-down. Every gift is a unit in a single cash waqf pool managed by Kitabisa's licensed nazhir. The core promise is one sentence: a gift that keeps on giving.

What carries over from Birrul: the perpetual fund, the kebaikan ledger, dates as the recurring anchor, every disbursement tracing to a stated intent, the person (not the balance) as the hero of the page. What changed: the occasion is any life moment, and the giver, not the family, initiates.

## Naming and language

The verb is **plant** (Indonesian: **menanam**). Never use "donate", "donation" or "spend" in user-facing copy.

| Concept | Indonesian | English | Never say |
| --- | --- | --- | --- |
| Product | Kado Abadi | The gift that keeps on giving | Donation platform |
| The act | Timmy menanam kebaikan untuk Thomas | Timmy planted a gift for Thomas | Timmy donated |
| The artifact | Sertifikat Kebaikan | Certificate of Kindness | Receipt |
| The fund | Pohon kebaikan Thomas | Thomas's fund | Balance, account |
| A disbursement | Buah pertama sudah dipetik | The first harvest | Payout |
| Top-up by others | Ikut menanam | Plant alongside | Contribute |

## Core loop

Giver picks occasion, person, cause, amount → pays → units minted in waqf pool → poster + QR + living page created → WhatsApp from Kitabisa official number → recipient opens living page → anniversary updates every year, forever → others plant alongside → more units minted.

The poster is the hook; the living page is what people return to. The anniversary update (birthday, wedding date, haul) is the retention mechanic.

First WhatsApp message, zero ask:

> Hai James, Timmy baru menanam kebaikan untuk Thomas. Setiap tahun, 2 pohon ditanam atas nama Thomas, selamanya. Lihat sertifikatnya: [link]

## Pool model

One pool, not a million tiny funds. Every gift buys units in a single Kado Abadi cash waqf pool. Kitabisa's nazhir manages the principal; the yield, net of the nazhir fee (max 10% of net surplus under UU 41/2004), is disbursed to causes.

- Unit price fixed at Rp 1,000 at launch; Rp 1jt = 1,000 units.
- Each gift records a cause and region preference. The pool disburses per cause in proportion to units tagged to that cause.
- Attribution is pro-rata: when 4,000 trees are planted, every tree-tagged gift alive on that date receives its share.
- Principal is never disbursed.
- Others can plant alongside an existing gift; their units attach to the same page.

## Impact calculator

Default view 10 years, slider to 100, crossover year highlighted.

| Constant | Value | Basis |
| --- | --- | --- |
| Gross yield | 7% | CWLS / sukuk, approximate |
| Nazhir fee | 10% of surplus | UU 41/2004 cap |
| Net yield r | 6% | Gross minus fee, rounded down |
| Crossover year | 17 | ceil(1 / r) |

    units(N)  = floor(A * r * N / c)
    oneTime   = floor(A / c)
    crossover = ceil(1 / r)

A = gift amount, r = net yield, N = years, c = unit cost of the cause. Implemented in `calc.js`.

Worked example, Rp 1jt into trees at Rp 25k:

| Horizon | Eternal gift | One-time gift | Principal remaining |
| --- | --- | --- | --- |
| Year 1 | 2 trees | 40 trees | Rp 1jt |
| Year 10 | 24 trees | 40 trees | Rp 1jt |
| Year 17 | 40 trees | 40 trees | Rp 1jt |
| Year 100 | 240 trees | 40 trees | Rp 1jt |

Display rules: always show one-time vs eternal vs principal side by side; label every future number "proyeksi"; conservative unit costs; actuals replace projections on the timeline.

## Causes

A cause qualifies if it has a stable unit cost and repeats from yield. One-off high-cost causes are excluded from v1. Unit costs are approximate until partner quotes replace them.

| Cause | Unit | Approx. cost (Rp) | Rhythm | v1 |
| --- | --- | --- | --- | --- |
| Tanam pohon | trees | 25,000 | Quarterly, rainy season | Yes |
| Beri makan | meals | 15,000 | Monthly, Jumat berkah | Yes |
| Bulan sekolah | child-months | 300,000 | Semester | Yes |
| Air bersih | people served/day | 50,000 per person-year | Quarterly | Later |
| Mangrove | seedlings | 20,000 | Rainy season | Later |
| Mushaf / buku | copies | 60,000 | Semester | Later |
| Pakan hewan terlantar | feeding-months | 30,000 | Monthly | Later |
| Wakaf sumur | one well per N years | 15,000,000 | Every few years | Later |

## Micro-transparency stamp

Every disbursement on a living page carries the same eight fields, small grey type, always present: date delivered, partner (link to partner page), location, units, amount, proof photos (GPS-tagged), your share, intent line.

Partner page per nonprofit: legal status, license, causes served, every past delivery, on-time rate, total units delivered. Missed windows show.

Cadence: WhatsApp update when a stamp lands that includes the recipient's share, plus one anniversary summary per year.

## MVP: four screens

| Route | Purpose |
| --- | --- |
| `#/` | Landing, four occasions |
| `#/create` | Single form with live calculator |
| `#/gift/:id` | Living page: poster hero, principal, 1/10/100 strip, timeline of stamps |
| `#/poster/:id` | 1080x1350 poster with photo, seal, fund ID, QR |

Stubbed in v1: payment, poster compositing (template not generative), disbursements (seeded), WhatsApp (logged).

## Data model

    Gift        { id, occasion, occasionDate, giver{name, wa}, recipient{name, photoUrl, wa, consentAttested},
                  cause, region, message, amount, units, unitPriceAtMint, posterUrl, createdAt }
    PoolEvent   { id, type: MINT|DISBURSE|YIELD, date, amount, cause, partnerId, location,
                  unitsDelivered, proofUrls[], intentLine }
    Attribution { giftId, poolEventId, unitsShare, amountShare }
    Partner     { id, name, legalStatus, licenseUrl, causes[], onTimeRate, totalUnitsDelivered }

Rules: Projection is computed, never stored. Attribution rows are written when a DISBURSE lands, one per gift alive with the matching cause. Every DISBURSE must carry an intentLine or it is refused.

## Risks and decisions

| Risk | Decision |
| --- | --- |
| Newborn photo in an AI generator | Template compositing only in v1. Giver attests permission. |
| Recipient never asked for a message | First WhatsApp from Kitabisa official number, zero ask, opt-out offered. |
| AI disclosure lowers giving | Label lightly ("dirancang untuk Thomas"), never "AI-generated". |
| Overstated impact | Conservative unit costs, "proyeksi" labels, actuals replace projections. |
| Yield below 6% | Constant updated from real returns; pages show actual stamps. |
| Waqf scope | Pool under Kitabisa's BWI nazhir registration. Confirm cause tagging is permitted. |
| Personal repo on Kitabisa brand | Decide ownership of domain and pool early. |

Open question: minimum gift. Rp 100k yields Rp 6k/year. Floor at Rp 250k or route small gifts into a shared occasion fund.
