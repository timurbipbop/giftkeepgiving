# Kado Abadi

The gift that keeps on giving. Send love as a perpetual fund: pick a person, a cause and an amount; we mint a stamped certificate with a QR code, deliver it via WhatsApp, and the gift keeps producing impact in their name, every year, forever.

Personal project by Alfa, built on Kitabisa's licensed nazhir and distribution. Read `docs/SPEC.md` first.

## What's here

| File | What |
| --- | --- |
| `index.html` | The whole v1 prototype: landing, create flow with live calculator, living gift page, poster. Static, hash-routed, no build step. |
| `calc.js` | Impact calculator and config constants (net yield, unit costs, causes, occasions). Pure functions. The one file the API must reuse. |
| `calc.test.js` | Tests that pin the spec's worked example. `node --test` |
| `docs/SPEC.md` | Product spec snapshot |
| `CLAUDE.md` | Working rules for anyone (human or Claude Code) touching this repo |

## Run locally

Open `index.html` in a browser, or `npx serve .` and visit the printed URL. Nothing to install.

## Deploy (GitHub Pages)

1. Push to `main`.
2. Repo → Settings → Pages → Source: Deploy from a branch → `main` / `/ (root)`.
3. Settings → Pages → Custom domain: enter your domain. GitHub adds a `CNAME` file to the repo.
4. At your DNS provider: `A` records for the apex to `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`; `CNAME` for `www` to `<your-github-username>.github.io`. Tick "Enforce HTTPS" once the certificate is issued.

## What is stubbed in v1

Payment (simulated), poster (template compositing, not generative), disbursement stamps (seeded on the demo gift), WhatsApp (message shown, not sent), persistence (browser localStorage only).

## Roadmap for the team

1. Move to Next.js on Vercel. Keep `calc.js` as the single source of the projection logic; import it on both client and server.
2. `POST /gifts` → payment intent (Kitabisa payment rail) → mint units → return gift id.
3. `GET /gifts/:id` living page with real Attribution rows; `GET /poster/:id` as a server-rendered 1080×1350 image (Vercel OG or satori).
4. WhatsApp Business API send from Kitabisa's official number: first message zero ask, opt-out included.
5. Admin: record `PoolEvent{type: DISBURSE}` with partner, location, proofs and a mandatory `intentLine`; write pro-rata `Attribution` for every gift alive with the matching cause.
6. Anniversary job: yearly WhatsApp summary per gift on the occasion date.
7. Partner pages with on-time rate and full delivery history.
